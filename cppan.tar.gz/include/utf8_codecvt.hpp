#define BOOST_UTF8_BEGIN_NAMESPACE namespace utf8CodeCvt {
#define BOOST_UTF8_END_NAMESPACE }
#define BOOST_UTF8_DECL 
#include "utf8_codecvt_facet.hpp"
